/* ═══════════════════════════════════
   AgroFlow v2 — Shared JS
   ═══════════════════════════════════ */

// ── DATA ──────────────────────────────────────────────────
const AF = {
  commodities: [
    {emoji:'🌾',name:'Wheat',        price:'₹23,480',open:'₹22,940',high:'₹23,600',low:'₹22,880',change:'+2.4%',pos:true, exchange:'NCDEX',spark:[80,82,79,85,88,84,90]},
    {emoji:'🍚',name:'Rice (Basmati)',price:'₹82,000',open:'₹75,680',high:'₹82,400',low:'₹75,200',change:'+8.4%',pos:true, exchange:'NCDEX',spark:[70,68,72,78,82,85,88]},
    {emoji:'🍅',name:'Tomato',        price:'₹1,840', open:'₹1,902', high:'₹1,920', low:'₹1,820', change:'-3.2%',pos:false,exchange:'APMC', spark:[60,65,58,52,50,48,46]},
    {emoji:'🧅',name:'Onion',         price:'₹2,100', open:'₹1,985', high:'₹2,140', low:'₹1,960', change:'+5.8%',pos:true, exchange:'APMC', spark:[40,42,48,55,60,64,68]},
    {emoji:'🌻',name:'Mustard Oil',   price:'₹14,200',open:'₹14,360',high:'₹14,420',low:'₹14,150',change:'-1.1%',pos:false,exchange:'MCX',  spark:[80,78,75,72,70,71,70]},
    {emoji:'🪴',name:'Cotton',        price:'₹61,800',open:'₹61,240',high:'₹62,100',low:'₹61,100',change:'+0.9%',pos:true, exchange:'MCX',  spark:[55,58,60,59,62,63,64]},
    {emoji:'🌽',name:'Maize',         price:'₹1,920', open:'₹1,890', high:'₹1,940', low:'₹1,880', change:'+1.6%',pos:true, exchange:'NCDEX',spark:[48,50,52,53,55,57,58]},
    {emoji:'🫘',name:'Soybean',       price:'₹4,480', open:'₹4,520', high:'₹4,540', low:'₹4,460', change:'-0.9%',pos:false,exchange:'NCDEX',spark:[65,64,62,60,58,59,58]},
  ],
  crops:[
    {emoji:'🌾',name:'Wheat (HD-2967)',      loc:'Punjab · 320 farms',     pct:92,color:'#D4A853',harvest:'Mar 20–25'},
    {emoji:'🌽',name:'Maize (PMH-1)',         loc:'Haryana · 180 farms',    pct:78,color:'#E07840',harvest:'Apr 01–10'},
    {emoji:'🍅',name:'Tomato (Arka Rakshak)', loc:'Karnataka · 95 farms',   pct:65,color:'#E07840',harvest:'Apr 05–15'},
    {emoji:'🧅',name:'Onion (Bhima Raj)',     loc:'Maharashtra · 145 farms',pct:88,color:'#3A7D44',harvest:'Mar 22–28'},
    {emoji:'🌻',name:'Sunflower (KBSH-44)',   loc:'Andhra · 107 farms',     pct:55,color:'#4A8FA8',harvest:'Apr 10–20'},
  ],
  shipments:[
    {icon:'🚛',id:'AGF-4821',    route:'Ludhiana Mandi → Delhi NCR Hub',eta:'ETA 14:30', qty:'48 MT Wheat',  state:'on-time'},
    {icon:'🚚',id:'AGF-4798',    route:'Nashik → Mumbai Cold Hub',      eta:'+2h delay', qty:'12 MT Onion',  state:'delayed'},
    {icon:'✈️',id:'AGF-EXP-192',route:'JNPT → Dubai (Export)',         eta:'ETA Mar 21',qty:'480 MT Basmati',state:'transit'},
    {icon:'🚛',id:'AGF-4835',    route:'Kolar → Bangalore Markets',     eta:'ETA 16:00', qty:'8 MT Tomato',  state:'on-time'},
    {icon:'🚂',id:'AGF-RAIL-88', route:'Jodhpur → Chennai (Rail)',      eta:'ETA Mar 20',qty:'320 MT Millet', state:'transit'},
    {icon:'🚛',id:'AGF-4840',    route:'Amritsar → Ludhiana Hub',       eta:'ETA 11:00', qty:'62 MT Wheat',  state:'on-time'},
    {icon:'🚚',id:'AGF-4801',    route:'Pune → Hyderabad Cold Hub',     eta:'+4h delay', qty:'22 MT Grapes', state:'delayed'},
  ],
  demand:[
    {day:'Mon',demand:72,stock:65},{day:'Tue',demand:88,stock:80},
    {day:'Wed',demand:65,stock:70},{day:'Thu',demand:95,stock:78},
    {day:'Fri',demand:82,stock:85},{day:'Sat',demand:110,stock:90},
    {day:'Sun',demand:98,stock:88},
  ],
  alerts:[
    {level:'critical',tag:'⚑ Critical Action',  color:'#C02020', msg:'Harvest Punjab wheat within 48h. 42°C+ forecast — 12% yield loss risk if delayed.',time:'2 min ago · AI Risk Engine'},
    {level:'warning', tag:'⚠ Logistics Alert',  color:'#C45C20', msg:'Reroute Nashik-Mumbai: NH-160 congested. NH-61 saves 2.4h and ₹8,400/truck.',    time:'18 min ago · Route Optimizer'},
    {level:'warning', tag:'⚠ Inventory Alert',  color:'#C45C20', msg:'Onion stock below 55% capacity. 34% shortfall forecast next week.',               time:'1 hour ago · Demand AI'},
    {level:'info',    tag:'ℹ Market Opportunity',color:'#4A8FA8', msg:'Basmati spot price up 8.4% at NCDEX. Lock in 200 MT at ₹82,000/MT.',             time:'3 hours ago · Market Intelligence'},
    {level:'info',    tag:'ℹ Export Window',     color:'#4A8FA8', msg:'UAE wheat quota opens Mar 22. Pre-register 480 MT for 12% tariff concession.',    time:'5 hours ago · Trade Analytics'},
  ]
};

// ── TOPBAR ────────────────────────────────────────────────
function injectTopbar() {
  const page = window.location.pathname.split('/').pop() || 'index.html';
  const nav = [
    {href:'dashboard.html', label:'Dashboard'},
    {href:'farms.html',     label:'Farm Network'},
    {href:'logistics.html', label:'Logistics'},
    {href:'markets.html',   label:'Markets'},
    {href:'analytics.html', label:'Analytics'},
    {href:'settings.html',  label:'Settings'},
  ];
  const navHTML = nav.map(n =>
    `<a href="${n.href}" class="nav-btn${page===n.href?' active':''}">${n.label}</a>`
  ).join('');
  const tb = document.createElement('header');
  tb.className = 'topbar';
  tb.innerHTML = `
    <a href="index.html" class="logo"><div class="logo-icon">🌿</div>AgroFlow</a>
    <nav class="nav" id="mainNav">${navHTML}</nav>
    <div class="topbar-right">
      <div class="status-dot"></div>
      <span class="status-txt">Live · 2 min ago</span>
      <div class="alert-btn">🔔<span class="alert-badge">3</span></div>
      <button class="hamburger" id="hbg" aria-label="Menu">
        <span></span><span></span><span></span>
      </button>
    </div>`;
  document.body.prepend(tb);
  document.getElementById('hbg').addEventListener('click', () => {
    document.getElementById('mainNav').classList.toggle('open');
  });
  document.addEventListener('click', e => {
    const nav = document.getElementById('mainNav');
    const hbg = document.getElementById('hbg');
    if (nav && hbg && !nav.contains(e.target) && !hbg.contains(e.target)) nav.classList.remove('open');
  });
}

// ── COMMAND BAR ───────────────────────────────────────────
const CMD_RESPONSES = {
  'show alerts':        () => `<strong>3 Active Alerts:</strong><br>⚑ Harvest wheat Punjab within 48h<br>⚠ Reroute NH-160 congestion<br>⚠ Onion stock below threshold`,
  'crop status':        () => `<strong>Crop Readiness:</strong><br>🌾 Wheat 92% · 🧅 Onion 88%<br>🌽 Maize 78% · 🍅 Tomato 65%<br>🌻 Sunflower 55%`,
  'wheat price':        () => `<strong>Wheat (NCDEX):</strong> ₹23,480/MT<br>▲ +2.4% today · High: ₹23,600<br>7-day trend: Rising ↑`,
  'shipments':          () => `<strong>Active Shipments:</strong> 128 total<br>✅ On-time: 94 · ⚠ Delayed: 12<br>✈ In transit: 22 (exports)`,
  'inventory':          () => `<strong>Inventory Summary:</strong><br>🌾 Wheat: 24,800/30,000 MT (83%)<br>🧅 Onion: 4,200/8,000 MT ⚠<br>🍅 Tomato: 1,840/3,000 MT`,
  'weather':            () => `<strong>Weather — Next 3 Days:</strong><br>☀ Today: 38°C Clear<br>⛅ Tomorrow: 36°C Partly cloudy<br>🌧 Day 3: 28°C Rain likely`,
  'revenue':            () => `<strong>Farmer Revenue Uplift:</strong> +23%<br>vs traditional channels<br>₹28Cr paid this month · 847 farms`,
  'optimize routes':    () => `<strong>Route Optimization:</strong> 94%<br>↑ 8pts vs manual routing<br>Fuel saved: ₹2.4L this month`,
  'farm count':         () => `<strong>Farm Network:</strong> 847 active farms<br>12 states · 1.2M acres<br>23 crop varieties tracked`,
  'co2':                () => `<strong>Sustainability:</strong><br>CO₂ saved: 2,140 tonnes<br>Water saved: 3.8B litres<br>Wastage reduced: 7.4% → 3.1%`,
  'help':               () => `<strong>You can ask me:</strong><br>• show alerts &nbsp;• crop status<br>• wheat price &nbsp;• shipments<br>• inventory &nbsp;&nbsp;• weather<br>• revenue &nbsp;&nbsp;&nbsp;&nbsp;• optimize routes<br>• farm count &nbsp;• co2`,
};

function matchCmd(input) {
  const q = input.toLowerCase().trim();
  for (const [key, fn] of Object.entries(CMD_RESPONSES)) {
    if (q.includes(key)) return fn();
  }
  // fuzzy
  if (q.includes('price') || q.includes('market')) return CMD_RESPONSES['wheat price']();
  if (q.includes('farm') || q.includes('crop'))    return CMD_RESPONSES['crop status']();
  if (q.includes('ship') || q.includes('truck') || q.includes('logistics')) return CMD_RESPONSES['shipments']();
  if (q.includes('stock') || q.includes('invent')) return CMD_RESPONSES['inventory']();
  if (q.includes('route') || q.includes('optim'))  return CMD_RESPONSES['optimize routes']();
  if (q.includes('weather') || q.includes('rain')) return CMD_RESPONSES['weather']();
  return `I found no specific data for "<em>${input}</em>".<br>Type <strong>help</strong> to see available commands.`;
}

function injectCommandBar() {
  const bar = document.createElement('div');
  bar.className = 'cmd-bar';
  bar.innerHTML = `
    <div class="cmd-panel" id="cmdPanel">
      <div class="cmd-header">
        <div>
          <div class="cmd-title">🌿 AgroFlow Command</div>
          <div class="cmd-sub">Ask anything about your supply chain</div>
        </div>
        <button class="cmd-close" id="cmdClose">✕</button>
      </div>
      <div class="cmd-messages" id="cmdMsgs">
        <div class="msg msg-bot">👋 Hello! I'm your supply chain assistant.<br>Ask me about crops, prices, shipments, weather, or inventory. Type <strong>help</strong> for all commands.</div>
      </div>
      <div class="cmd-suggestions">
        <span class="cmd-sug" data-q="show alerts">show alerts</span>
        <span class="cmd-sug" data-q="crop status">crop status</span>
        <span class="cmd-sug" data-q="wheat price">wheat price</span>
        <span class="cmd-sug" data-q="shipments">shipments</span>
        <span class="cmd-sug" data-q="weather">weather</span>
        <span class="cmd-sug" data-q="inventory">inventory</span>
      </div>
      <div class="cmd-input-row">
        <input class="cmd-input" id="cmdInput" placeholder="Type a command..." autocomplete="off">
        <button class="cmd-send" id="cmdSend">➤</button>
      </div>
    </div>
    <button class="cmd-fab" id="cmdFab" title="Open Command Bar">💬</button>`;
  document.body.appendChild(bar);

  const panel = document.getElementById('cmdPanel');
  const fab   = document.getElementById('cmdFab');
  const msgs  = document.getElementById('cmdMsgs');
  const input = document.getElementById('cmdInput');

  fab.addEventListener('click', () => { panel.classList.toggle('open'); if(panel.classList.contains('open')) input.focus(); });
  document.getElementById('cmdClose').addEventListener('click', () => panel.classList.remove('open'));

  function sendMsg() {
    const q = input.value.trim(); if (!q) return;
    msgs.innerHTML += `<div class="msg msg-user">${q}</div>`;
    setTimeout(() => {
      msgs.innerHTML += `<div class="msg msg-bot">${matchCmd(q)}</div>`;
      msgs.scrollTop = msgs.scrollHeight;
    }, 400);
    input.value = '';
    msgs.scrollTop = msgs.scrollHeight;
  }

  document.getElementById('cmdSend').addEventListener('click', sendMsg);
  input.addEventListener('keydown', e => { if (e.key === 'Enter') sendMsg(); });
  document.querySelectorAll('.cmd-sug').forEach(s => {
    s.addEventListener('click', () => { input.value = s.dataset.q; sendMsg(); });
  });
}

// ── HELPERS ──────────────────────────────────────────────
function sparkSVG(data, pos) {
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v,i) => {
    const x = i * (50 / (data.length-1));
    const y = 20 - ((v-min) / ((max-min)||1)) * 18;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const c = pos ? '#3A7D44' : '#C45C20';
  return `<svg width="54" height="22" viewBox="0 0 54 22" style="overflow:visible"><polyline points="${pts}" fill="none" stroke="${c}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

function renderDemandBars(id) {
  const el = document.getElementById(id); if (!el) return;
  const maxV = Math.max(...AF.demand.map(d=>d.demand));
  el.innerHTML = AF.demand.map(d => {
    const dh = Math.round((d.demand/maxV)*80);
    const sh = Math.round((d.stock/maxV)*80);
    return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px">
      <div style="font-size:9px;font-weight:600;color:var(--soil);font-family:var(--mono)">${d.demand}k</div>
      <div style="display:flex;gap:2px;align-items:flex-end;height:80px">
        <div style="height:${dh}px;background:var(--leaf);width:10px;border-radius:2px 2px 0 0;opacity:.9"></div>
        <div style="height:${sh}px;background:var(--sky);width:10px;border-radius:2px 2px 0 0;opacity:.45"></div>
      </div>
      <div style="font-size:9px;color:var(--text-muted);font-family:var(--mono)">${d.day}</div>
    </div>`;
  }).join('');
}

function renderMarketTable(tbodyId, extended) {
  const tbody = document.getElementById(tbodyId); if (!tbody) return;
  AF.commodities.forEach(c => {
    const tr = document.createElement('tr');
    if (extended) {
      tr.innerHTML = `
        <td style="font-weight:600">${c.emoji} ${c.name}</td>
        <td style="font-family:var(--mono);font-weight:600">${c.price}</td>
        <td style="font-family:var(--mono);font-size:11px;color:var(--text-muted)">${c.open}</td>
        <td style="font-family:var(--mono);font-size:11px;color:var(--leaf)">${c.high}</td>
        <td style="font-family:var(--mono);font-size:11px;color:var(--harvest)">${c.low}</td>
        <td class="${c.pos?'c-pos':'c-neg'}">${c.pos?'▲':'▼'} ${c.change}</td>
        <td>${sparkSVG(c.spark,c.pos)}</td>
        <td style="font-family:var(--mono);font-size:10px;color:var(--text-muted)">${c.exchange}</td>`;
    } else {
      tr.innerHTML = `
        <td style="font-weight:600">${c.emoji} ${c.name}</td>
        <td style="font-family:var(--mono);font-weight:500">${c.price}</td>
        <td class="${c.pos?'c-pos':'c-neg'}">${c.pos?'▲':'▼'} ${c.change}</td>
        <td>${sparkSVG(c.spark,c.pos)}</td>
        <td style="font-family:var(--mono);font-size:10px;color:var(--text-muted)">${c.exchange}</td>`;
    }
    tbody.appendChild(tr);
  });
}

function renderCropBars(id) {
  const el = document.getElementById(id); if (!el) return;
  el.innerHTML = AF.crops.map(c => `
    <div style="display:flex;align-items:center;gap:10px;padding:9px 11px;border-radius:8px;background:rgba(26,15,8,0.04);border:1px solid transparent;margin-bottom:7px;cursor:pointer;transition:all .2s" onmouseover="this.style.borderColor='var(--border)'" onmouseout="this.style.borderColor='transparent'">
      <span style="font-size:19px">${c.emoji}</span>
      <div style="flex:1">
        <div style="font-size:12px;font-weight:600;color:var(--soil)">${c.name}</div>
        <div style="font-size:10px;color:var(--text-muted);font-family:var(--mono)">${c.loc}</div>
      </div>
      <div style="width:76px">
        <div style="font-size:10px;color:var(--text-muted);text-align:right;margin-bottom:2px;font-family:var(--mono)">${c.pct}%</div>
        <div style="height:4px;border-radius:2px;background:rgba(26,15,8,0.08);overflow:hidden">
          <div style="width:${c.pct}%;height:100%;border-radius:2px;background:${c.color}"></div>
        </div>
      </div>
    </div>`).join('');
}

function renderShipments(id, count) {
  const el = document.getElementById(id); if (!el) return;
  const list = count ? AF.shipments.slice(0,count) : AF.shipments;
  el.innerHTML = list.map(s => `
    <div class="shipment ${s.state}">
      <span style="font-size:17px">${s.icon}</span>
      <div style="flex:1">
        <div style="font-size:11px;font-weight:700;color:var(--soil);font-family:var(--mono)">${s.id}</div>
        <div style="font-size:10px;color:var(--text-muted)">${s.route}</div>
      </div>
      <div style="text-align:right">
        <div style="font-size:11px;font-weight:600;color:${s.state==='delayed'?'var(--harvest)':'var(--soil)'}">${s.eta}</div>
        <div style="font-size:9px;color:var(--text-muted);font-family:var(--mono)">${s.qty}</div>
      </div>
    </div>`).join('');
}

function renderAlerts(id, count) {
  const el = document.getElementById(id); if (!el) return;
  const list = count ? AF.alerts.slice(0,count) : AF.alerts;
  el.innerHTML = list.map(a => `
    <div class="alert-item ${a.level}">
      <div class="alert-tag">${a.tag}</div>
      <div class="alert-msg">${a.msg}</div>
      <div class="alert-time">${a.time}</div>
    </div>`).join('');
}

function initChainStages() {
  document.querySelectorAll('.chain-stage').forEach(s => {
    s.addEventListener('click', function() {
      document.querySelectorAll('.chain-stage').forEach(x => { if(!x.classList.contains('warn')) x.classList.remove('active'); });
      this.classList.toggle('active');
    });
  });
}

// ── INIT ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  injectTopbar();
  injectCommandBar();
  renderDemandBars('forecastBars');
  renderMarketTable('marketTableBody', false);
  renderMarketTable('marketTableBodyExt', true);
  renderCropBars('cropList');
  renderShipments('shipmentList', 5);
  renderShipments('shipmentListFull', null);
  renderAlerts('alertList', 5);
  renderAlerts('alertListFull', null);
  initChainStages();
});
