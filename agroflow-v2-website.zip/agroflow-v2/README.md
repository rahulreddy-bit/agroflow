# 🌿 AgroFlow v2 — Agricultural Supply Chain Platform
### GitHub Pages Ready · Fully Mobile Responsive · AI Command Bar

---

## 📁 File Structure

```
agroflow-v2/
├── index.html        ← Landing page + Login
├── dashboard.html    ← Main dashboard (full)
├── farms.html        ← Farm Network
├── logistics.html    ← Shipments & Route Optimization
├── markets.html      ← Commodity Prices & Contracts
├── analytics.html    ← Reports & AI Performance
├── settings.html     ← Integrations, Users, Config
├── css/
│   └── style.css     ← All shared styles
└── js/
    └── app.js        ← All data, charts, command bar, topbar
```

---

## 🚀 Deploy to GitHub Pages (FREE — 5 Minutes)

### Step 1: Create GitHub Repository
1. Go to **https://github.com/new**
2. Repository name: `agroflow` (or anything)
3. Set to **Public**
4. Click **Create repository**

### Step 2: Upload Files

**Option A — GitHub Web (No Git needed)**
1. Open your new repo on GitHub
2. Click **"Add file" → "Upload files"**
3. Drag your entire `agroflow-v2` folder contents
4. Maintain the folder structure:
   - Root: `index.html`, `dashboard.html`, `farms.html`, etc.
   - `css/style.css`
   - `js/app.js`
5. Click **"Commit changes"**

**Option B — Git Terminal**
```bash
cd agroflow-v2
git init
git add .
git commit -m "AgroFlow v2 - Supply Chain Platform"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/agroflow.git
git push -u origin main
```

### Step 3: Enable GitHub Pages
1. Go to your repo → **Settings**
2. Left sidebar → **Pages**
3. Source: **Deploy from a branch**
4. Branch: **main** / **/ (root)**
5. Click **Save**

### Step 4: Your Website is Live! 🎉
```
https://YOUR_USERNAME.github.io/agroflow/
```
*(Takes 1–3 minutes to go live after saving)*

---

## 🌐 Other Free Hosting Options

| Platform | How | URL Format |
|----------|-----|------------|
| **Netlify** | Drag & drop folder at netlify.com | `agroflow.netlify.app` |
| **Vercel** | Connect GitHub repo | `agroflow.vercel.app` |
| **Cloudflare Pages** | Connect GitHub repo | `agroflow.pages.dev` |

---

## 📱 Pages & Features

| Page | Description |
|------|-------------|
| `index.html` | Login page with demo access |
| `dashboard.html` | Full dashboard: KPIs, supply chain, forecasts |
| `farms.html` | Farm network, crops, harvest schedule |
| `logistics.html` | Shipments, route optimization, cold chain |
| `markets.html` | Commodity prices, contracts, alerts |
| `analytics.html` | AI performance, waste, sustainability |
| `settings.html` | Integrations, notifications, users |

### 💬 Command Bar (All Pages)
Click the **💬 button** (bottom-right) on any page to open the AI Command Bar.

Available commands:
- `show alerts` — View active alerts
- `crop status` — Crop readiness summary
- `wheat price` — Latest wheat market data
- `shipments` — Active shipment overview
- `inventory` — Inventory levels
- `weather` — 3-day forecast
- `revenue` — Farmer revenue stats
- `optimize routes` — Route optimization score
- `farm count` — Network statistics
- `co2` — Sustainability metrics
- `help` — Show all commands

---

## ⚙️ Tech Stack

| Item | Detail |
|------|--------|
| Language | Pure HTML5, CSS3, Vanilla JavaScript |
| Fonts | Syne, DM Mono, Crimson Pro (Google Fonts) |
| Framework | None — zero dependencies |
| Build step | None — open any `.html` file directly |
| Mobile | Fully responsive (480px → 1440px) |
| Hosting | Any static host (GitHub Pages, Netlify, Vercel) |

---

## 🛠 Customization

### Change Platform Name
Find and replace `AgroFlow` in all HTML files.

### Change Color Scheme
Edit CSS variables in `css/style.css`:
```css
:root {
  --leaf: #3A7D44;    /* Primary green */
  --wheat: #D4A853;   /* Gold/amber accent */
  --soil: #2C1A0E;    /* Dark text */
  --cream: #F5EDD8;   /* Background */
}
```

### Add Real Data
In `js/app.js`, replace the `AF` data object arrays with API fetch calls:
```javascript
// Replace static data with:
const response = await fetch('https://your-api.com/commodities');
AF.commodities = await response.json();
```

### Add New Command Bar Responses
In `js/app.js`, add to `CMD_RESPONSES`:
```javascript
const CMD_RESPONSES = {
  'your command': () => `<strong>Response:</strong> your data here`,
  // ...existing commands
};
```

---

## 📞 Support

Built with AgroFlow v2.0 · Season Rabi 2025–26
